import React from 'react'

function AnnualFireCertification() {
  return (
    <div>AnnualFireCertification</div>
  )
}

export default AnnualFireCertification