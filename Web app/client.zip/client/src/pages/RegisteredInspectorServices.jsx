import React from 'react'

function RegisteredInspectorServices() {
  return (
    <div>RegisteredInspectorServices</div>
  )
}

export default RegisteredInspectorServices